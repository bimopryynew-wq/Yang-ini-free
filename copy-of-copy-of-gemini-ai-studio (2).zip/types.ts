
import React from 'react';
import { SparklesIcon, ChatBubbleLeftRightIcon, PhotoIcon, VideoCameraIcon, MicrophoneIcon, SpeakerWaveIcon, DocumentTextIcon } from './components/Icons';

export enum AppFeature {
  Chatbot = 'chatbot',
  ImageStudio = 'image_studio',
  VideoStudio = 'video_studio',
  VoiceAssistant = 'voice_assistant',
  TextPlayground = 'text_playground',
  TextToSpeech = 'text_to_speech',
  AudioTranscription = 'audio_transcription',
}

export interface Feature {
  id: AppFeature;
  name: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export const FEATURES: Feature[] = [
  { id: AppFeature.Chatbot, name: 'Chatbot', icon: ChatBubbleLeftRightIcon },
  { id: AppFeature.TextPlayground, name: 'Text Playground', icon: SparklesIcon },
  { id: AppFeature.ImageStudio, name: 'Image Studio', icon: PhotoIcon },
  { id: AppFeature.VideoStudio, name: 'Video Studio', icon: VideoCameraIcon },
  { id: AppFeature.VoiceAssistant, name: 'Voice Assistant', icon: MicrophoneIcon },
  { id: AppFeature.TextToSpeech, name: 'Text to Speech', icon: SpeakerWaveIcon },
  { id: AppFeature.AudioTranscription, name: 'Audio Transcription', icon: DocumentTextIcon },
];

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export type AspectRatio = "1:1" | "16:9" | "9:16" | "4:3" | "3:4";
