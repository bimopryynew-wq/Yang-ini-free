import { useState, useEffect, useCallback } from 'react';

declare global {
    interface Window {
        // FIX: Made aistudio optional to resolve declaration modifier conflicts.
        aistudio?: {
            hasSelectedApiKey: () => Promise<boolean>;
            openSelectKey: () => Promise<void>;
        };
    }
}

export const useApiKeyCheck = () => {
    const [isKeySelected, setIsKeySelected] = useState(false);
    const [isChecking, setIsChecking] = useState(true);

    const checkApiKey = useCallback(async () => {
        setIsChecking(true);
        if (window.aistudio) {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            setIsKeySelected(hasKey);
        } else {
            setIsKeySelected(false);
        }
        setIsChecking(false);
    }, []);

    useEffect(() => {
        checkApiKey();
    }, [checkApiKey]);

    const selectApiKey = useCallback(async () => {
        if (window.aistudio) {
            await window.aistudio.openSelectKey();
            // Assume success to avoid race conditions and immediately enable UI
            setIsKeySelected(true);
        }
    }, []);
    
    const resetApiKey = useCallback(() => {
        setIsKeySelected(false);
    }, []);

    return { isKeySelected, isChecking, selectApiKey, resetApiKey, checkApiKey };
};
