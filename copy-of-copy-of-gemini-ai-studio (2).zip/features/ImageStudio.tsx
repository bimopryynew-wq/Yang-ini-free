
import React, { useState } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { AspectRatio } from '../types';
import { blobToBase64 } from '../utils/helpers';

type StudioMode = 'generate' | 'edit' | 'analyze';

const ImageStudio: React.FC = () => {
  const [mode, setMode] = useState<StudioMode>('generate');
  const [prompt, setPrompt] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setImageUrl(URL.createObjectURL(file));
      setGeneratedImage(null);
      setAnalysisResult('');
    }
  };
  
  const handleSubmit = async () => {
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);
    setAnalysisResult('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      switch (mode) {
        case 'generate':
          const genResponse = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: aspectRatio,
            },
          });
          const base64ImageBytes = genResponse.generatedImages[0].image.imageBytes;
          setGeneratedImage(`data:image/jpeg;base64,${base64ImageBytes}`);
          break;
          
        case 'edit':
        case 'analyze':
          if (!imageFile) throw new Error("Please upload an image.");
          
          const base64Data = await blobToBase64(imageFile);
          const imagePart = {
            inlineData: {
              data: base64Data,
              mimeType: imageFile.type,
            },
          };
          const textPart = { text: prompt || (mode === 'analyze' ? 'Describe this image in detail.' : '') };
          
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: mode === 'edit' ? { responseModalities: [Modality.IMAGE] } : undefined,
          });

          if (mode === 'edit') {
            const part = response.candidates[0].content.parts[0];
            if (part && part.inlineData) {
              setGeneratedImage(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
            } else {
              throw new Error("The model did not return an image. It might have refused the request.");
            }
          } else { // analyze
            setAnalysisResult(response.text);
          }
          break;
      }
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Failed to process request: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = () => (
    <div className="flex-1 flex flex-col md:flex-row gap-6">
      <div className="md:w-1/2 flex flex-col items-center justify-center p-4 bg-gray-800 rounded-lg">
        {mode !== 'generate' && (
          <div className="w-full">
            <label htmlFor="file-upload" className="cursor-pointer block w-full p-4 border-2 border-dashed border-gray-600 rounded-lg text-center hover:border-indigo-500 transition-colors">
              {imageUrl ? <img src={imageUrl} alt="Upload preview" className="max-h-64 mx-auto rounded-md" /> : <span className="text-gray-400">Click to upload an image</span>}
            </label>
            <input id="file-upload" type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
          </div>
        )}
        {(mode === 'generate' || (mode === 'edit' && generatedImage)) && (
          <div className="w-full flex items-center justify-center">
            {isLoading && mode === 'generate' && <div className="w-full aspect-square bg-gray-700 animate-pulse rounded-lg"></div>}
            {!isLoading && !generatedImage && mode === 'generate' && <div className="w-full aspect-square flex items-center justify-center bg-gray-700 rounded-lg text-gray-500">Your image will appear here</div>}
            {generatedImage && <img src={generatedImage} alt="Generated" className="max-h-80 mx-auto rounded-md" />}
          </div>
        )}
        {mode === 'analyze' && analysisResult && (
          <div className="mt-4 p-4 bg-gray-900 rounded-md w-full max-h-48 overflow-y-auto">
            <h3 className="font-semibold mb-2">Analysis Result:</h3>
            <p className="text-sm text-gray-300 whitespace-pre-wrap">{analysisResult}</p>
          </div>
        )}
      </div>
      <div className="md:w-1/2 flex flex-col justify-center">
          {error && <div className="bg-red-900/50 text-red-300 p-3 rounded-md mb-4">{error}</div>}
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              mode === 'generate' ? "A futuristic cityscape at sunset..." :
              mode === 'edit' ? "Add a retro filter..." :
              "What's in this image?"
            }
            className="w-full h-32 bg-gray-700 border border-gray-600 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-4"
            disabled={isLoading}
          />
          {mode === 'generate' && (
              <div className="mb-4">
                  <label htmlFor="aspect-ratio" className="block text-sm font-medium text-gray-300 mb-2">Aspect Ratio</label>
                  <select
                      id="aspect-ratio"
                      value={aspectRatio}
                      onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                      className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                      <option value="1:1">Square (1:1)</option>
                      <option value="16:9">Landscape (16:9)</option>
                      <option value="9:16">Portrait (9:16)</option>
                      <option value="4:3">Standard (4:3)</option>
                      <option value="3:4">Tall (3:4)</option>
                  </select>
              </div>
          )}
          <button
            onClick={handleSubmit}
            disabled={isLoading || (mode !== 'generate' && !imageFile) || !prompt.trim()}
            className="w-full bg-indigo-600 text-white py-3 rounded-md font-semibold hover:bg-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
          >
            {isLoading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : 
            (mode.charAt(0).toUpperCase() + mode.slice(1))}
          </button>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-1">Image Studio</h2>
        <p className="text-gray-400">Generate, edit, and understand images with AI.</p>
        <div className="mt-4 flex gap-2 p-1 bg-gray-800 rounded-lg w-fit">
          {(['generate', 'edit', 'analyze'] as StudioMode[]).map(m => (
            <button key={m} onClick={() => setMode(m)} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${mode === m ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`}>
              {m.charAt(0).toUpperCase() + m.slice(1)}
            </button>
          ))}
        </div>
      </div>
      {renderContent()}
    </div>
  );
};

export default ImageStudio;
