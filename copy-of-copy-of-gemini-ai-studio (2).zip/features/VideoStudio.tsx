
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { useApiKeyCheck } from '../hooks/useApiKeyCheck';
import { blobToBase64 } from '../utils/helpers';

type VideoMode = 'text-to-video' | 'image-to-video';
type AspectRatioVideo = '16:9' | '9:16';

const LOADING_MESSAGES = [
    "Warming up the digital director's chair...",
    "Teaching pixels to dance...",
    "Storyboarding with algorithms...",
    "Rendering your vision into reality...",
    "This can take a few minutes, good things come to those who wait!",
];

const VideoStudio: React.FC = () => {
    const { isKeySelected, isChecking, selectApiKey, resetApiKey } = useApiKeyCheck();
    const [mode, setMode] = useState<VideoMode>('text-to-video');
    const [prompt, setPrompt] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [aspectRatio, setAspectRatio] = useState<AspectRatioVideo>('16:9');
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(LOADING_MESSAGES[0]);
    const [error, setError] = useState<string | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setImageFile(file);
            setImageUrl(URL.createObjectURL(file));
        }
    };
    
    const handleSubmit = async () => {
        if (!isKeySelected) {
            setError("Please select an API key first.");
            return;
        }
        if (mode === 'image-to-video' && !imageFile) {
            setError("Please upload an image to animate.");
            return;
        }
        if (!prompt && mode === 'text-to-video') {
            setError("Please enter a prompt.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setVideoUrl(null);
        
        let messageInterval = setInterval(() => {
            setLoadingMessage(prev => {
                const currentIndex = LOADING_MESSAGES.indexOf(prev);
                return LOADING_MESSAGES[(currentIndex + 1) % LOADING_MESSAGES.length];
            });
        }, 4000);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            let operation;
            if (mode === 'image-to-video' && imageFile) {
                const base64Data = await blobToBase64(imageFile);
                operation = await ai.models.generateVideos({
                    model: 'veo-3.1-fast-generate-preview',
                    prompt: prompt,
                    image: { imageBytes: base64Data, mimeType: imageFile.type },
                    config: { numberOfVideos: 1, resolution: '720p', aspectRatio: aspectRatio }
                });
            } else {
                 operation = await ai.models.generateVideos({
                    model: 'veo-3.1-fast-generate-preview',
                    prompt: prompt,
                    config: { numberOfVideos: 1, resolution: '720p', aspectRatio: aspectRatio }
                });
            }
            
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                operation = await ai.operations.getVideosOperation({ operation: operation });
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (downloadLink) {
                 const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                 const videoBlob = await videoResponse.blob();
                 setVideoUrl(URL.createObjectURL(videoBlob));
            } else {
                throw new Error("Video generation completed, but no video URI was found.");
            }

        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            if (errorMessage.includes("Requested entity was not found")) {
                setError("API Key error. Please re-select your key.");
                resetApiKey();
            } else {
                setError(`Failed to generate video: ${errorMessage}`);
            }
        } finally {
            setIsLoading(false);
            clearInterval(messageInterval);
        }
    };

    if (isChecking) {
        return <div className="text-center p-8">Checking API Key status...</div>
    }

    if (!isKeySelected) {
        return (
            <div className="h-full flex flex-col items-center justify-center text-center bg-gray-800 rounded-lg p-8">
                <h2 className="text-2xl font-bold mb-2">API Key Required for Veo</h2>
                <p className="text-gray-400 mb-4">Video generation with Veo requires you to select a project with billing enabled.</p>
                <p className="text-xs text-gray-500 mb-6">Learn more about billing at <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">ai.google.dev/gemini-api/docs/billing</a>.</p>
                <button onClick={selectApiKey} className="bg-indigo-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-indigo-500">
                    Select API Key
                </button>
            </div>
        )
    }

    return (
        <div className="h-full flex flex-col">
            <h2 className="text-2xl font-bold mb-1">Video Studio</h2>
            <p className="text-gray-400 mb-6">Generate stunning videos from text or images using Veo.</p>
            
            <div className="flex gap-2 p-1 bg-gray-800 rounded-lg w-fit mb-6">
              {(['text-to-video', 'image-to-video'] as VideoMode[]).map(m => (
                <button key={m} onClick={() => setMode(m)} className={`px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${mode === m ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`}>
                  {m === 'text-to-video' ? 'Text to Video' : 'Image to Video'}
                </button>
              ))}
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-6">
                <div className="md:w-1/2 flex flex-col">
                    {mode === 'image-to-video' && (
                        <div className="mb-4">
                            <label htmlFor="file-upload" className="cursor-pointer block w-full p-4 border-2 border-dashed border-gray-600 rounded-lg text-center hover:border-indigo-500 transition-colors">
                            {imageUrl ? <img src={imageUrl} alt="Upload preview" className="max-h-48 mx-auto rounded-md" /> : <span className="text-gray-400">Click to upload an image</span>}
                            </label>
                            <input id="file-upload" type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                        </div>
                    )}
                    <textarea
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        placeholder="A majestic whale breaching from a sea of clouds..."
                        className="w-full flex-1 bg-gray-700 border border-gray-600 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-4"
                        disabled={isLoading}
                    />
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-300 mb-2">Aspect Ratio</label>
                        <div className="flex gap-2">
                           {(['16:9', '9:16'] as AspectRatioVideo[]).map(ratio => (
                                <button key={ratio} onClick={() => setAspectRatio(ratio)} className={`px-4 py-2 text-sm rounded-md transition-colors ${aspectRatio === ratio ? 'bg-indigo-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>
                                    {ratio}
                                </button>
                           ))}
                        </div>
                    </div>
                    <button
                        onClick={handleSubmit}
                        disabled={isLoading}
                        className="w-full bg-indigo-600 text-white py-3 rounded-md font-semibold hover:bg-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                    >
                        Generate Video
                    </button>
                    {error && <div className="bg-red-900/50 text-red-300 p-3 rounded-md mt-4">{error}</div>}
                </div>
                <div className="md:w-1/2 flex items-center justify-center p-4 bg-gray-800 rounded-lg">
                    {isLoading && (
                        <div className="text-center">
                            <div className="w-12 h-12 border-4 border-indigo-400 border-t-transparent rounded-full animate-spin mx-auto"></div>
                            <p className="mt-4 text-gray-300">{loadingMessage}</p>
                        </div>
                    )}
                    {!isLoading && !videoUrl && <div className="text-gray-500">Your generated video will appear here.</div>}
                    {videoUrl && <video src={videoUrl} controls autoPlay loop className="max-w-full max-h-full rounded-md" />}
                </div>
            </div>
        </div>
    );
};

export default VideoStudio;
