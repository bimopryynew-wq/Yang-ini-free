import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob, LiveSession } from '@google/genai';
import { decode, decodeAudioData, createBlob } from '../utils/helpers';
import { MicrophoneIcon } from '../components/Icons';

type ConversationState = 'idle' | 'listening' | 'connecting' | 'error';
interface Transcription {
    user: string;
    model: string;
}

const VoiceAssistant: React.FC = () => {
    const [conversationState, setConversationState] = useState<ConversationState>('idle');
    const [transcriptionHistory, setTranscriptionHistory] = useState<Transcription[]>([]);
    const [currentTranscription, setCurrentTranscription] = useState<Transcription>({ user: '', model: ''});
    const [error, setError] = useState<string | null>(null);

    const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const nextStartTimeRef = useRef<number>(0);
    const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

    const stopConversation = useCallback(() => {
        if (sessionPromiseRef.current) {
            sessionPromiseRef.current.then(session => session.close());
            sessionPromiseRef.current = null;
        }

        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }

        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }

        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }
        
        if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
            outputAudioContextRef.current.close();
            outputAudioContextRef.current = null;
        }
        
        audioSourcesRef.current.forEach(source => source.stop());
        audioSourcesRef.current.clear();
        nextStartTimeRef.current = 0;

        setConversationState('idle');
    }, []);
    
    // Cleanup on unmount
    useEffect(() => {
        return () => stopConversation();
    }, [stopConversation]);

    const startConversation = async () => {
        if (conversationState !== 'idle' && conversationState !== 'error') return;

        setConversationState('connecting');
        setError(null);
        setCurrentTranscription({ user: '', model: '' });
        setTranscriptionHistory([]);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // FIX: Cast window to any to allow access to vendor-prefixed webkitAudioContext for cross-browser compatibility.
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

            let currentInputTranscription = '';
            let currentOutputTranscription = '';

            sessionPromiseRef.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        setConversationState('listening');
                        // FIX: Cast window to any to allow access to vendor-prefixed webkitAudioContext for cross-browser compatibility.
                        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                        const source = audioContextRef.current.createMediaStreamSource(stream);
                        scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
                        
                        scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            if (sessionPromiseRef.current) {
                                sessionPromiseRef.current.then((session) => {
                                    session.sendRealtimeInput({ media: pcmBlob });
                                });
                            }
                        };
                        source.connect(scriptProcessorRef.current);
                        scriptProcessorRef.current.connect(audioContextRef.current.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.inputTranscription) {
                            currentInputTranscription += message.serverContent.inputTranscription.text;
                             setCurrentTranscription(prev => ({...prev, user: currentInputTranscription}));
                        }
                        if (message.serverContent?.outputTranscription) {
                            currentOutputTranscription += message.serverContent.outputTranscription.text;
                            setCurrentTranscription(prev => ({...prev, model: currentOutputTranscription}));
                        }

                        if (message.serverContent?.turnComplete) {
                            setTranscriptionHistory(prev => [...prev, {user: currentInputTranscription, model: currentOutputTranscription}]);
                            currentInputTranscription = '';
                            currentOutputTranscription = '';
                            setCurrentTranscription({user: '', model: ''});
                        }

                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio && outputAudioContextRef.current) {
                            const outputCtx = outputAudioContextRef.current;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            const sourceNode = outputCtx.createBufferSource();
                            sourceNode.buffer = audioBuffer;
                            sourceNode.connect(outputCtx.destination);
                            
                            sourceNode.onended = () => audioSourcesRef.current.delete(sourceNode);
                            sourceNode.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            audioSourcesRef.current.add(sourceNode);
                        }

                        if (message.serverContent?.interrupted) {
                            audioSourcesRef.current.forEach(source => source.stop());
                            audioSourcesRef.current.clear();
                            nextStartTimeRef.current = 0;
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Live API Error:', e);
                        setError(`An error occurred: ${e.message}`);
                        setConversationState('error');
                        stopConversation();
                    },
                    onclose: () => {
                        stopConversation();
                    },
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' }}},
                    systemInstruction: 'You are a friendly and helpful AI assistant.'
                }
            });

        } catch (err) {
            console.error('Failed to start conversation:', err);
            setError('Could not access microphone. Please check permissions.');
            setConversationState('error');
        }
    };
    
    const getButtonState = () => {
        switch (conversationState) {
            case 'idle':
            case 'error':
                return { text: 'Start Conversation', action: startConversation, color: 'bg-indigo-600 hover:bg-indigo-500' };
            case 'connecting':
                return { text: 'Connecting...', action: () => {}, color: 'bg-yellow-600', disabled: true };
            case 'listening':
                return { text: 'Stop Conversation', action: stopConversation, color: 'bg-red-600 hover:bg-red-500' };
        }
    };
    
    const { text, action, color, disabled } = getButtonState();

    return (
        <div className="h-full flex flex-col p-4 bg-gray-800 rounded-lg shadow-xl">
            <div className="text-center mb-6">
                <h2 className="text-2xl font-bold">Voice Assistant</h2>
                <p className="text-gray-400">Talk to Gemini in real-time.</p>
            </div>
            <div className="flex-1 flex flex-col items-center justify-center">
                <button
                    onClick={action}
                    disabled={disabled}
                    className={`relative w-40 h-40 rounded-full flex items-center justify-center text-white font-semibold text-lg transition-colors duration-300 ${color} ${disabled ? 'cursor-not-allowed' : ''}`}
                >
                    {conversationState === 'listening' && (
                        <span className="absolute h-full w-full rounded-full bg-indigo-400 opacity-75 animate-ping"></span>
                    )}
                    <MicrophoneIcon className="h-16 w-16" />
                </button>
                <p className="mt-4 font-medium">{text}</p>
                {error && <p className="mt-2 text-red-400">{error}</p>}
            </div>
             <div className="h-64 bg-gray-900 rounded-lg p-4 overflow-y-auto scroll-container">
                <h3 className="text-lg font-semibold mb-2 text-gray-300">Transcription</h3>
                <div className="space-y-3 text-sm">
                    {transcriptionHistory.map((t, i) => (
                        <div key={i}>
                            <p><strong className="text-indigo-400">You:</strong> {t.user}</p>
                            <p><strong className="text-teal-400">Gemini:</strong> {t.model}</p>
                        </div>
                    ))}
                    {(currentTranscription.user || currentTranscription.model) && (
                         <div>
                            <p className="text-gray-400"><strong className="text-indigo-400">You:</strong> {currentTranscription.user}</p>
                            <p className="text-gray-400"><strong className="text-teal-400">Gemini:</strong> {currentTranscription.model}</p>
                        </div>
                    )}
                    {transcriptionHistory.length === 0 && !currentTranscription.user && !currentTranscription.model && (
                        <p className="text-gray-500">Transcript will appear here...</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default VoiceAssistant;