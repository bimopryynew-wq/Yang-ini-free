import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { decode, decodeAudioData } from '../utils/helpers';
import { SpeakerWaveIcon } from '../components/Icons';

const TextToSpeech: React.FC = () => {
    const [text, setText] = useState('Hello! I am Gemini, a powerful AI model from Google. Have a wonderful day!');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    const cleanupAudio = useCallback(() => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.disconnect();
            audioSourceRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }
    }, []);

    useEffect(() => {
        return () => cleanupAudio();
    }, [cleanupAudio]);

    const handleGenerateSpeech = async () => {
        if (!text.trim()) {
            setError('Please enter some text to generate speech.');
            return;
        }
        setIsLoading(true);
        setError(null);
        cleanupAudio();

        try {
            // FIX: Cast window to any to allow access to vendor-prefixed webkitAudioContext for cross-browser compatibility.
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-tts",
                contents: [{ parts: [{ text: `Say with a friendly tone: ${text}` }] }],
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: {
                        voiceConfig: {
                            prebuiltVoiceConfig: { voiceName: 'Kore' },
                        },
                    },
                },
            });

            const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

            if (base64Audio && audioContextRef.current) {
                const audioBuffer = await decodeAudioData(
                    decode(base64Audio),
                    audioContextRef.current,
                    24000,
                    1,
                );
                audioSourceRef.current = audioContextRef.current.createBufferSource();
                audioSourceRef.current.buffer = audioBuffer;
                audioSourceRef.current.connect(audioContextRef.current.destination);
                audioSourceRef.current.start();
            } else {
                throw new Error('No audio data received from the API.');
            }
        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to generate speech: ${errorMessage}`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="h-full flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-2xl bg-gray-800 p-8 rounded-lg shadow-xl text-center">
                <SpeakerWaveIcon className="h-16 w-16 mx-auto text-indigo-400 mb-4"/>
                <h2 className="text-2xl font-bold mb-2">Text to Speech</h2>
                <p className="text-gray-400 mb-6">Bring your text to life with natural-sounding AI voices.</p>
                
                <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Enter text to convert to speech..."
                    className="w-full h-40 bg-gray-700 border border-gray-600 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-4"
                    disabled={isLoading}
                />
                
                <button
                    onClick={handleGenerateSpeech}
                    disabled={isLoading || !text.trim()}
                    className="w-full bg-indigo-600 text-white py-3 rounded-md font-semibold hover:bg-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Generating Audio...' : 'Generate & Play Speech'}
                </button>

                {error && <div className="bg-red-900/50 text-red-300 p-3 rounded-md mt-4 text-left">{error}</div>}
            </div>
        </div>
    );
};

export default TextToSpeech;