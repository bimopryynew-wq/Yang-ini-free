
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { blobToBase64 } from '../utils/helpers';
import { MicrophoneIcon } from '../components/Icons';

type RecordingState = 'idle' | 'recording' | 'processing' | 'error';

const AudioTranscription: React.FC = () => {
    const [recordingState, setRecordingState] = useState<RecordingState>('idle');
    const [transcribedText, setTranscribedText] = useState<string>('');
    const [error, setError] = useState<string | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);
            
            mediaRecorderRef.current.ondataavailable = (event) => {
                audioChunksRef.current.push(event.data);
            };

            mediaRecorderRef.current.onstop = async () => {
                setRecordingState('processing');
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                audioChunksRef.current = [];
                stream.getTracks().forEach(track => track.stop()); // Stop mic access
                
                try {
                    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                    const base64Data = await blobToBase64(audioBlob);
                    
                    const response = await ai.models.generateContent({
                        model: 'gemini-2.5-flash',
                        contents: {
                            parts: [
                                { inlineData: { data: base64Data, mimeType: 'audio/webm' } },
                                { text: "Transcribe this audio recording." }
                            ]
                        }
                    });
                    
                    setTranscribedText(response.text);
                    setRecordingState('idle');
                } catch (e) {
                    console.error(e);
                    setError(e instanceof Error ? e.message : 'An unknown error occurred during transcription.');
                    setRecordingState('error');
                }
            };
            
            mediaRecorderRef.current.start();
            setRecordingState('recording');
            setTranscribedText('');
            setError(null);
        } catch (err) {
            console.error('Error accessing microphone:', err);
            setError('Could not access microphone. Please check permissions.');
            setRecordingState('error');
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && recordingState === 'recording') {
            mediaRecorderRef.current.stop();
        }
    };

    const getButtonState = () => {
        switch (recordingState) {
            case 'recording':
                return { text: 'Stop Recording', action: stopRecording, color: 'bg-red-600 hover:bg-red-500' };
            case 'processing':
                 return { text: 'Processing...', action: () => {}, color: 'bg-yellow-600', disabled: true };
            case 'idle':
            case 'error':
            default:
                return { text: 'Start Recording', action: startRecording, color: 'bg-indigo-600 hover:bg-indigo-500' };
        }
    };

    const { text, action, color, disabled } = getButtonState();

    return (
        <div className="h-full flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-3xl bg-gray-800 p-8 rounded-lg shadow-xl">
                <h2 className="text-2xl font-bold mb-2 text-center">Audio Transcription</h2>
                <p className="text-gray-400 mb-8 text-center">Record your voice and get a text transcript using Gemini.</p>
                
                <div className="text-center mb-8">
                    <button
                        onClick={action}
                        disabled={disabled}
                        className={`inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full text-white font-semibold transition-colors ${color} ${disabled ? 'cursor-not-allowed opacity-70' : ''}`}
                    >
                         {recordingState === 'recording' && <span className="absolute h-4 w-4 rounded-full bg-white opacity-75 animate-ping"></span>}
                        <MicrophoneIcon className="h-6 w-6" />
                        <span>{text}</span>
                    </button>
                    {error && <p className="mt-4 text-red-400">{error}</p>}
                </div>

                <div className="bg-gray-900 rounded-lg p-4 min-h-[150px]">
                    <h3 className="text-lg font-semibold mb-2 text-gray-300">Transcript:</h3>
                    {transcribedText ? (
                        <p className="text-gray-200 whitespace-pre-wrap">{transcribedText}</p>
                    ) : (
                        <p className="text-gray-500">Your transcript will appear here after recording.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AudioTranscription;
