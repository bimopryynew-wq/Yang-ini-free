
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';

type TextModel = 'gemini-2.5-pro' | 'gemini-2.5-flash' | 'gemini-2.5-flash-lite';

const TextPlayground: React.FC = () => {
    const [model, setModel] = useState<TextModel>('gemini-2.5-flash');
    const [prompt, setPrompt] = useState('');
    const [result, setResult] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [useThinking, setUseThinking] = useState(false);
    const [useSearch, setUseSearch] = useState(false);
    const [useMaps, setUseMaps] = useState(false);
    const [groundingLinks, setGroundingLinks] = useState<any[]>([]);

    const handleSubmit = async () => {
        setIsLoading(true);
        setError(null);
        setResult('');
        setGroundingLinks([]);
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            const tools: any[] = [];
            if (useSearch) tools.push({ googleSearch: {} });
            if (useMaps) tools.push({ googleMaps: {} });
            
            const config: any = {};
            if (tools.length > 0) config.tools = tools;
            if (useThinking && model === 'gemini-2.5-pro') {
                config.thinkingConfig = { thinkingBudget: 32768 };
            }
            
            const response = await ai.models.generateContent({
                model: model,
                contents: prompt,
                config: Object.keys(config).length > 0 ? config : undefined,
            });

            setResult(response.text);

            if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
                setGroundingLinks(response.candidates[0].groundingMetadata.groundingChunks);
            }
            
        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to generate content: ${errorMessage}`);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="h-full flex flex-col">
            <h2 className="text-2xl font-bold mb-1">Text Playground</h2>
            <p className="text-gray-400 mb-6">Experiment with Gemini's powerful text generation models.</p>
            
            <div className="flex flex-col md:flex-row gap-6 flex-1">
                <div className="md:w-1/3 flex flex-col gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
                        <select
                            value={model}
                            onChange={e => {
                                const newModel = e.target.value as TextModel;
                                setModel(newModel);
                                if (newModel !== 'gemini-2.5-pro') {
                                    setUseThinking(false);
                                }
                            }}
                            className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="gemini-2.5-flash">Flash (Fast & General)</option>
                            <option value="gemini-2.5-flash-lite">Flash Lite (Ultra-Fast)</option>
                            <option value="gemini-2.5-pro">Pro (Complex Tasks)</option>
                        </select>
                    </div>

                    <div className="space-y-3">
                         <label className="block text-sm font-medium text-gray-300">Enhancements</label>
                        <div className="flex items-center">
                            <input
                                id="thinking-mode"
                                type="checkbox"
                                checked={useThinking}
                                onChange={e => setUseThinking(e.target.checked)}
                                disabled={model !== 'gemini-2.5-pro'}
                                className="h-4 w-4 rounded border-gray-500 bg-gray-700 text-indigo-600 focus:ring-indigo-500 disabled:opacity-50"
                            />
                            <label htmlFor="thinking-mode" className={`ml-2 text-sm ${model !== 'gemini-2.5-pro' ? 'text-gray-500' : 'text-gray-300'}`}>
                                Thinking Mode (Pro only)
                            </label>
                        </div>
                         <div className="flex items-center">
                            <input
                                id="search-grounding"
                                type="checkbox"
                                checked={useSearch}
                                onChange={e => setUseSearch(e.target.checked)}
                                className="h-4 w-4 rounded border-gray-500 bg-gray-700 text-indigo-600 focus:ring-indigo-500"
                            />
                            <label htmlFor="search-grounding" className="ml-2 text-sm text-gray-300">
                                Google Search Grounding
                            </label>
                        </div>
                        <div className="flex items-center">
                            <input
                                id="maps-grounding"
                                type="checkbox"
                                checked={useMaps}
                                onChange={e => setUseMaps(e.target.checked)}
                                className="h-4 w-4 rounded border-gray-500 bg-gray-700 text-indigo-600 focus:ring-indigo-500"
                            />
                            <label htmlFor="maps-grounding" className="ml-2 text-sm text-gray-300">
                                Google Maps Grounding
                            </label>
                        </div>
                    </div>

                    <textarea
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        placeholder="Write a python script to sort a list of numbers..."
                        className="w-full flex-1 bg-gray-800 border border-gray-600 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        disabled={isLoading}
                    />

                    <button
                        onClick={handleSubmit}
                        disabled={isLoading || !prompt.trim()}
                        className="w-full bg-indigo-600 text-white py-3 rounded-md font-semibold hover:bg-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                    >
                        {isLoading ? 'Generating...' : 'Generate'}
                    </button>
                </div>

                <div className="md:w-2/3 flex flex-col bg-gray-800 rounded-lg p-4">
                    <h3 className="text-lg font-semibold mb-2 text-gray-200">Result</h3>
                    {error && <div className="bg-red-900/50 text-red-300 p-3 rounded-md">{error}</div>}
                    <div className="flex-1 bg-gray-900 rounded-md p-3 overflow-y-auto scroll-container">
                        {isLoading ? <div className="text-gray-400">Generating response...</div> :
                         result ? <pre className="whitespace-pre-wrap text-sm text-gray-200">{result}</pre> :
                         <div className="text-gray-500">Output will appear here.</div>
                        }
                    </div>
                    {groundingLinks.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-gray-700">
                            <h4 className="text-md font-semibold mb-2">Sources:</h4>
                            <ul className="list-disc list-inside text-sm space-y-1">
                                {groundingLinks.map((chunk, index) => {
                                    const source = chunk.web || chunk.maps;
                                    if (source?.uri) {
                                      return (
                                        <li key={index}>
                                            <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">
                                                {source.title || source.uri}
                                            </a>
                                        </li>
                                      );
                                    }
                                    return null;
                                })}
                            </ul>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default TextPlayground;
