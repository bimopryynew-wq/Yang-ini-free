
import React, { useState, useMemo } from 'react';
import { AppFeature, FEATURES } from './types';
import Sidebar from './components/Sidebar';
import Chatbot from './features/Chatbot';
import ImageStudio from './features/ImageStudio';
import VideoStudio from './features/VideoStudio';
import VoiceAssistant from './features/VoiceAssistant';
import TextPlayground from './features/TextPlayground';
import TextToSpeech from './features/TextToSpeech';
import AudioTranscription from './features/AudioTranscription';

const App: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<AppFeature>(AppFeature.Chatbot);

  const ActiveComponent = useMemo(() => {
    switch (activeFeature) {
      case AppFeature.Chatbot:
        return Chatbot;
      case AppFeature.ImageStudio:
        return ImageStudio;
      case AppFeature.VideoStudio:
        return VideoStudio;
      case AppFeature.VoiceAssistant:
        return VoiceAssistant;
      case AppFeature.TextPlayground:
        return TextPlayground;
      case AppFeature.TextToSpeech:
        return TextToSpeech;
      case AppFeature.AudioTranscription:
        return AudioTranscription;
      default:
        return () => <div className="text-center p-8">Select a feature</div>;
    }
  }, [activeFeature]);

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100">
      <Sidebar activeFeature={activeFeature} setActiveFeature={setActiveFeature} />
      <main className="flex-1 overflow-y-auto scroll-container">
        <div className="p-4 sm:p-6 md:p-8 h-full">
          <ActiveComponent />
        </div>
      </main>
    </div>
  );
};

export default App;
