
import React from 'react';
import { AppFeature, FEATURES } from '../types';
import { GeminiLogo } from './Icons';

interface SidebarProps {
  activeFeature: AppFeature;
  setActiveFeature: (feature: AppFeature) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeFeature, setActiveFeature }) => {
  return (
    <aside className="w-64 bg-gray-800 p-4 flex flex-col">
      <div className="flex items-center gap-2 mb-8">
        <GeminiLogo className="h-8 w-8 text-indigo-400" />
        <h1 className="text-xl font-bold text-white">Gemini Studio</h1>
      </div>
      <nav className="flex flex-col gap-2">
        {FEATURES.map((feature) => (
          <button
            key={feature.id}
            onClick={() => setActiveFeature(feature.id)}
            className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              activeFeature === feature.id
                ? 'bg-indigo-600 text-white'
                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
            }`}
          >
            <feature.icon className="h-5 w-5" />
            <span>{feature.name}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
